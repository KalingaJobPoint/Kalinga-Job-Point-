<?php
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function categories(){return ['Helper','Driver','Security','Cleaner','Construction','Hotel & Restaurant','Factory','Office','Sales','Other'];}
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return $_SESSION['csrf'];}
function check_csrf(){if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??''))die('Invalid request.');}
function logged_in(){return !empty($_SESSION['user_id']);}
function admin(){return !empty($_SESSION['admin']);}
function require_login(){if(!logged_in())header('Location: login.php?next=post-job.php');}
function require_admin(){if(!admin())header('Location: admin.php');}
?>