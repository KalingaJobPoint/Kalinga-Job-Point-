<?php
session_start(); require_once 'config.php'; require_once 'functions.php';
if($_SERVER['REQUEST_METHOD']!=='POST') die('Invalid request.');
check_csrf();
$id=(int)($_POST['job_id']??0);
$s=db()->prepare("SELECT id FROM jobs WHERE id=? AND status='approved'");$s->execute([$id]);
if(!$s->fetch()) die('Job not found.');
$st=db()->prepare("INSERT INTO reports(job_id,name,email,reason) VALUES(?,?,?,?)");
$st->execute([$id,trim($_POST['name']??''),trim($_POST['email']??''),trim($_POST['reason'])]);
header('Location: job.php?id='.$id.'&reported=1'); exit;
?>