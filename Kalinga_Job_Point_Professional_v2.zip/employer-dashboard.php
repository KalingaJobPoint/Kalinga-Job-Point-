<?php
session_start();require_once 'config.php';require_once 'functions.php';require_login();
$uid=(int)$_SESSION['user_id'];
$s=db()->prepare("SELECT * FROM jobs WHERE posted_by=? ORDER BY created_at DESC");$s->execute([$uid]);$jobs=$s->fetchAll(PDO::FETCH_ASSOC);
$s=db()->prepare("SELECT a.*,j.title FROM applications a JOIN jobs j ON j.id=a.job_id WHERE j.posted_by=? ORDER BY a.created_at DESC");$s->execute([$uid]);$apps=$s->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Employer Dashboard</title><link rel="stylesheet" href="style.css"></head><body><?php include 'nav.php';?><main class="wrap"><div class="section-head"><h1>Employer Dashboard</h1><a class="btn" href="post-job.php">Post Free Job</a></div>
<h2>My Jobs</h2><div class="cards"><?php foreach($jobs as $j):?><article class="job"><span class="tag"><?=e($j['status'])?></span><h3><?=e($j['title'])?></h3><p><?=e($j['company'])?> · <?=e($j['location'])?></p><a class="btn" href="job.php?id=<?=$j['id']?>">View</a></article><?php endforeach;if(!$jobs):?><div class="panel">No jobs posted yet.</div><?php endif;?></div>
<h2>Applications</h2><div class="panel"><table><tr><th>Applicant</th><th>Phone</th><th>Job</th><th>Resume</th><th>Status</th></tr><?php foreach($apps as $a):?><tr><td><?=e($a['name'])?></td><td><?=e($a['phone'])?></td><td><?=e($a['title'])?></td><td><?php if($a['resume']):?><a href="<?=e($a['resume'])?>" target="_blank">Open</a><?php else:?>—<?php endif;?></td><td><?=e($a['status'])?></td></tr><?php endforeach;?></table></div>
</main></body></html>