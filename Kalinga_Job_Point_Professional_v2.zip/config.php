<?php
const DB_FILE = __DIR__.'/data/kalinga.sqlite';
const SITE_NAME = 'Kalinga Job Point';
const ADMIN_EMAIL = 'admin@kalingajobpoint.local';
const ADMIN_PASSWORD = 'ChangeThisAdminPassword123!'; // CHANGE before public deployment
function db(){ static $pdo; if(!$pdo){ if(!is_dir(__DIR__.'/data')) mkdir(__DIR__.'/data',0755,true); $pdo=new PDO('sqlite:'.DB_FILE); $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); $pdo->exec("PRAGMA foreign_keys=ON"); } return $pdo; }
?>