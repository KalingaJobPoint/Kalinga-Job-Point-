# Kalinga Job Point — Complete Starter Portal

This package is a PHP + SQLite job portal designed for free/low-cost hosting.

## Features
- Public job search: keyword, location, category
- Employer/user registration and login
- Free job posting
- Admin approval before publication
- Job detail page
- Free online application
- My Applications page
- Admin dashboard for pending jobs and recent applications
- Responsive mobile-first UI
- SQLite database, no paid database required

## Install
1. Upload all files to a PHP hosting account that supports PHP 8+ and SQLite/PDO_SQLite.
2. Open `/setup.php` once in the browser.
3. Delete or protect `setup.php`.
4. IMPORTANT: edit `config.php` and change ADMIN_EMAIL and ADMIN_PASSWORD before public launch.
5. Open `/index.php`.

## Important production upgrades
- Use HTTPS.
- Change the admin password.
- Add email verification and password reset.
- Add CAPTCHA/rate limiting.
- Add privacy policy, terms and consent.
- Add employer verification and stronger anti-fraud moderation.
- Restrict uploaded files if resume uploads are added.
- Back up the SQLite database.
- For larger traffic, migrate from SQLite to MySQL/PostgreSQL.

## Free hosting
Any PHP host with SQLite/PDO_SQLite can run this starter. Hosting providers change their free-tier rules, so verify current limits before choosing one.

## Professional v2 additions
- Resume upload (PDF/DOC/DOCX, max 3 MB)
- WhatsApp Apply button
- Employer dashboard
- Applicant resume links for employers
- Report Job form
- Admin reported-job review list
- Admin approval remains mandatory for new jobs

Before launch, change the admin credentials in config.php, enable HTTPS, and configure backups and access controls for uploaded resumes.
