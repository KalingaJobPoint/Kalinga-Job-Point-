<?php
require_once 'config.php';
$db=db();
$db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,phone TEXT,password_hash TEXT NOT NULL,role TEXT DEFAULT 'seeker',created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,company TEXT NOT NULL,location TEXT NOT NULL,category TEXT NOT NULL,salary TEXT,description TEXT NOT NULL,contact TEXT,expires_at TEXT,status TEXT DEFAULT 'pending',posted_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(posted_by) REFERENCES users(id) ON DELETE SET NULL)");
$db->exec("CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY AUTOINCREMENT,job_id INTEGER NOT NULL,name TEXT NOT NULL,email TEXT,phone TEXT NOT NULL,experience TEXT,resume TEXT,status TEXT DEFAULT 'new',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(job_id) REFERENCES jobs(id) ON DELETE CASCADE)");
echo "<h2>Kalinga Job Point setup complete.</h2><p>Delete or protect setup.php before public deployment.</p><p><a href='index.php'>Open website</a></p>"; ?>