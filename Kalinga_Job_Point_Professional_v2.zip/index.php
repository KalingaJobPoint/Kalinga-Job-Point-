<?php
session_start();
require_once __DIR__.'/config.php';
require_once __DIR__.'/functions.php';
$jobs = db()->query("SELECT * FROM jobs WHERE status='approved' AND (expires_at IS NULL OR expires_at='' OR expires_at>=date('now')) ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kalinga Job Point</title><link rel="stylesheet" href="style.css"></head>
<body><?php include 'nav.php'; ?>
<section class="hero"><div class="wrap"><h1>Find a Job. Post a Job. Free.</h1><p>हर नौकरी की सही जानकारी, एक ही जगह।</p>
<form class="search" method="get" action="jobs.php"><input name="q" placeholder="Job title / keyword"><input name="location" placeholder="Location / Country"><select name="category"><option value="">All Categories</option><?php foreach(categories() as $c):?><option><?=e($c)?></option><?php endforeach;?></select><button>Search Jobs</button></form></div></section>
<main class="wrap"><div class="section-head"><h2>Latest Jobs</h2><a class="btn" href="post-job.php">Post Free Job</a></div>
<div class="cards"><?php foreach(array_slice($jobs,0,12) as $j): include 'job-card.php'; endforeach; if(!$jobs):?><div class="panel">No jobs available yet.</div><?php endif;?></div>
<section class="features"><div><b>🔎 Free Job Search</b><span>Search by country, location and category.</span></div><div><b>💼 Free Job Posting</b><span>Employers can submit vacancies for approval.</span></div><div><b>📝 Easy Apply</b><span>Applicants can apply online without charge.</span></div></section>
<div class="notice">⚠️ Never pay money only because someone promises a job. Verify the employer, offer, visa and contract before making any payment.</div></main>
<?php include 'footer.php';?></body></html>