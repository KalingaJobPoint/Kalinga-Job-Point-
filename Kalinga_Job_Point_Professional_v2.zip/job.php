<?php session_start();require_once 'config.php';require_once 'functions.php';$id=(int)($_GET['id']??0);$s=db()->prepare("SELECT * FROM jobs WHERE id=? AND status='approved'");$s->execute([$id]);$j=$s->fetch(PDO::FETCH_ASSOC);if(!$j)die('Job not found.');$msg='';if($_SERVER['REQUEST_METHOD']==='POST'){
check_csrf();
$resume='';
if(isset($_FILES['resume']) && $_FILES['resume']['error']===UPLOAD_ERR_OK){
  $allowed=['pdf'=>'application/pdf','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
  $ext=strtolower(pathinfo($_FILES['resume']['name'],PATHINFO_EXTENSION));
  if(isset($allowed[$ext]) && $_FILES['resume']['size']<=3*1024*1024){
    $resume='uploads/resumes/'.bin2hex(random_bytes(10)).'.'.$ext;
    move_uploaded_file($_FILES['resume']['tmp_name'],__DIR__.'/'.$resume);
  }
}
$st=db()->prepare("INSERT INTO applications(job_id,name,email,phone,experience,resume) VALUES(?,?,?,?,?,?)");
$st->execute([$id,trim($_POST['name']),trim($_POST['email']),trim($_POST['phone']),trim($_POST['experience']),$resume]);
$msg='Application submitted successfully.';}?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($j['title'])?> - Kalinga Job Point</title><link rel="stylesheet" href="style.css"></head><body><?php include 'nav.php';?><main class="wrap"><div class="grid2"><section class="panel"><span class="tag"><?=e($j['category'])?></span><h1><?=e($j['title'])?></h1><h3><?=e($j['company'])?></h3><p>📍 <?=e($j['location'])?></p><p>💰 <b><?=e($j['salary'])?></b></p><p><?=nl2br(e($j['description']))?></p><p>📞 <?=e($j['contact'])?></p></section><section class="panel"><h2>Apply Now — Free</h2><?php if($msg):?><div class="success"><?=$msg?></div><?php endif;?><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=csrf()?>"><input name="name" required placeholder="Full name"><input type="email" name="email" placeholder="Email"><input name="phone" required placeholder="Phone / WhatsApp"><textarea name="experience" placeholder="Experience / short message"></textarea><label>Resume (PDF/DOC/DOCX, max 3 MB)<input type="file" name="resume" accept=".pdf,.doc,.docx"></label><button>Submit Application</button></form>
<?php if(!empty($j['contact'])): $wa=preg_replace('/[^0-9]/','',$j['contact']); if($wa):?><a class="btn whatsapp" target="_blank" href="https://wa.me/<?=$wa?>?text=<?=rawurlencode('Hello, I am interested in '.$j['title'].' at '.$j['company'].' via Kalinga Job Point.')?>">Apply via WhatsApp</a><?php endif;endif;?>
<hr><h3>Report this Job</h3><form method="post" action="report.php"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="job_id" value="<?=$id?>"><input name="name" placeholder="Your name"><input type="email" name="email" placeholder="Email"><textarea name="reason" required placeholder="Why are you reporting this job?"></textarea><button class="danger">Report Job</button></form></section></div></main><?php include 'footer.php';?></body></html>